import React from 'react';
// import Matka from './components/Matka';
import Lomake from './components/ObjectHook';





function App(){

	return (
		<div> 
		
		{ /* <Matka test={ matkat }/> */ }
		<Lomake />


		</div>);

}

export default App;