import React from 'react';
// import Matka from './components/Matka';
import Henkilolomake from './components/Henkilolomake';





function App(){

	return (
		<div> 
		
		{ /* <Matka test={ matkat }/> */ }
		<Henkilolomake />


		</div>);

}

export default App;