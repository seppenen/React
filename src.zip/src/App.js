import React from 'react'
import Fetch from './components/fetchTehtava'
import Fetch2 from './components/fetchTehtava2'

export default function App(){


    return (
		<div> 

        <Fetch/>
        <Fetch2/>

    </div>);

    }


