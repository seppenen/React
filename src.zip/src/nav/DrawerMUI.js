import React, { useState } from 'react';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Drawer from '@material-ui/core/Drawer';
import IconButton from '@material-ui/core/IconButton';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import HomeIcon from '@material-ui/icons/Home';
import CreateIcon from '@material-ui/icons/Create';
import MenuIcon from '@material-ui/icons/Menu';
import CloudQueueIcon from '@material-ui/icons/CloudQueue';
import ListIcon from '@material-ui/icons/List';
import { makeStyles } from '@material-ui/core/styles';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';



function DrawerMUI () {

  const useStyles = makeStyles({
    paper: {
      background: 'black',
      color: 'white'
    }
  });

  const styles = useStyles();

const [open, setOpen] = useState(false);

const handleOpen = () => { 
  setOpen(true); 
} 

const handleMenu = (event) => { setMenuOpen(event.currentTarget); }

const handleClose = () => { 
  setOpen(false); 
  setMenuOpen(null); 
}



const [anchorMenu, setMenuOpen] = useState(null);

const menuVasen = <Menu 
anchorEl={ anchorMenu }
open={ Boolean(anchorMenu) }
onClose={ handleClose }>
<MenuItem onClick={ handleClose }> 
<ListItemIcon>
 <HomeIcon />
 </ListItemIcon> 
 <ListItemText primary='Tietoja' />
</MenuItem>

<MenuItem onClick={ handleClose }>
  <ListItemIcon><CreateIcon /></ListItemIcon>
<ListItemText primary='Omat tiedot' /> </MenuItem>

 </Menu>
 

  return (
    <div>
   
     
          <IconButton onClick={ handleOpen } color='inherit'><MenuIcon /></IconButton><br />
          <IconButton onClick={ handleMenu } color='inherit'><MenuIcon /></IconButton>{menuVasen}
      

      <Drawer  anchor='left' open={ open } onClick={ handleClose }>
      
      <List>
      <ListItem button>
        <ListItemIcon><HomeIcon /></ListItemIcon>
<ListItemText primary='Tietoja' /> </ListItem>

<ListItem button>
        <ListItemIcon><CreateIcon /></ListItemIcon>
<ListItemText primary='Omat tiedot' /> </ListItem>




    </List>
      
      </Drawer>
    </div>
  );
}

export default DrawerMUI;