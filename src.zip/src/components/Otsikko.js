import React from 'react';

function  Otsikko (props) {
    return (
        <h3>{props.teksti}</h3>
    )
}

export default Otsikko;
